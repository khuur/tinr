import pygame
import os


_image_library = {}
def get_image(path):
        global _image_library
        image = _image_library.get(path)
        image2 = _image_library.get(path)
        if image == None:
                canonicalized_path = path.replace('/', os.sep).replace('\\', os.sep)
                image = pygame.image.load(canonicalized_path)
                _image_library[path] = image
        return image

class Soldier():

    def __init__(self, screen):
        """Initialize the pig and set its starting position."""
        self.screen = screen

        # Load the pig image and set pig and screen to rect.
        self.image = pygame.image.load('./data/sword1.png')
        self.image2 = pygame.image.load('./data/sword2.png')
        self.rect = self.image.get_rect()
        self.screen_rect = screen.get_rect()
        self.orientation = True

        # Start the pig at the bottom center of the screen.
        self.rect.centerx = self.screen_rect.centerx
        self.rect.bottom = self.screen_rect.bottom

        # Speed of the pig
        self.pig_speed = 1.5
        self.center = float(self.pig_speed)

        # Set a variable for each movement.
        self.moving_right = False
        self.moving_left = False
        self.moving_up = False
        self.moving_down = False

        self.direction = ['right', 'left']

    def update(self):
        """Update the position of the pig."""

        if self.rect.right <= self.screen_rect.right:
            if self.moving_right:
                self.rect.centerx += self.pig_speed

        if self.rect.left > 0:
            if self.moving_left:
                self.rect.centerx -= self.pig_speed

        if self.rect.top > 0:
            if self.moving_up:
                self.rect.bottom -= self.pig_speed

        if self.rect.bottom <= self.screen_rect.bottom:
            if self.moving_down:
                self.rect.bottom += self.pig_speed

    def blitme(self):
        if self.orientation == True:
            self.screen.blit(self.image, self.rect)
        else:
            self.screen.blit(pygame.transform.flip(self.image, False, True), self.rect)

class House():

    def __init__(self, screen):
        """Initialize the pig and set its starting position."""
        self.screen = screen

        # Load the pig image and set pig and screen to rect.
        self.image = pygame.image.load('./data/house.png')
        self.rect = self.image.get_rect()
        self.screen_rect = screen.get_rect()
        self.orientation = True

        # Start the pig at the bottom center of the screen.
        self.rect.centerx = self.screen_rect.centerx
        self.rect.bottom = self.screen_rect.bottom

       
    def blitme(self):
        if self.orientation == True:
            self.screen.blit(self.image, self.rect)
        else:
            self.screen.blit(pygame.transform.flip(self.image, False, True), self.rect)

class Crop():

    stage = 0;
    def __init__(self, screen):
        """Initialize the pig and set its starting position."""
        self.screen = screen

        # Load the pig image and set pig and screen to rect.
        self.image1 = pygame.image.load('./data/corn/idle_0.png')
        self.image2 = pygame.image.load('./data/corn/idle_1.png')
        self.image3 = pygame.image.load('./data/corn/idle_2.png')
        self.image4 = pygame.image.load('./data/corn/idle_3.png')
        self.image5 = pygame.image.load('./data/corn/idle_4.png')
        self.images =  [self.image1, self.image2, self.image3, self.image4, self.image5]
        self.rect = self.image1.get_rect()
        self.screen_rect = screen.get_rect()
        self.orientation = True

        # Start the pig at the bottom center of the screen.
        self.rect.centerx = self.screen_rect.centerx
        self.rect.bottom = self.screen_rect.bottom

       
    def blitme(self):
        if self.orientation == True:
            self.screen.blit(self.image, self.rect)
        else:
            self.screen.blit(pygame.transform.flip(self.image, False, True), self.rect)



def get_image(path):
	global _image_library
	image = _image_library.get(path)
	if image == None:
		canonicalized_path = path.replace('/', os.sep).replace('\\', os.sep)
		image = pygame.image.load(canonicalized_path)
		_image_library[path] = image
	return image
pygame.init()
screen = pygame.display.set_mode((800, 800))
done = False
is_blue = True
x = 30
y = 30


vojak = Soldier(screen);
hiska = House(screen);
corn  = Crop(screen);


clock = pygame.time.Clock()
while not done:
        for event in pygame.event.get():
                if event.type == pygame.QUIT:
                    done = True
                if event.type == pygame.KEYDOWN and event.key == pygame.K_SPACE:
                    vojak.orientation = not vojak.orientation
                if event.type == pygame.KEYDOWN and event.key == pygame.K_w:
                    corn.stage += 1
        
		
        pressed = pygame.key.get_pressed()
        if pressed[pygame.K_UP]: y -= 3
        if pressed[pygame.K_DOWN]: y += 3
        if pressed[pygame.K_LEFT]: x -= 3
        if pressed[pygame.K_RIGHT]: x += 3
        
        if is_blue: color = (0, 128, 255)
        else: color = (255, 100, 0)
        #pygame.draw.rect(screen, color, pygame.Rect(x, y, 20, 20))
        
        screen.fill((0,0,0))
        if vojak.orientation:
            screen.blit(get_image('./data/sword2_right.png'), (x, y))
        else:
            screen.blit(get_image('./data/sword2.png'), (x, y))
         
        screen.blit(get_image('./data/house.png'), (100,100))
        screen.blit(corn.images[corn.stage%5], (100,100))
		
        pygame.display.flip()
        clock.tick(60)
