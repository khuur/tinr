<template>
  <div id="app">
    <img width="25%" src="./assets/logo.png">
    <HelloWorld :msg="this.text_kiki"/>
  </div>
</template>

<script>
import HelloWorld from "./components/HelloWorld";
//import pgp from "pg-promise";

export default {
  name: "App",
  data() {
    return {
      text_kiki: ""
    };
  },
  components: {
    HelloWorld
  },
  methods: {
    async burek() {
      var tole_bom_vracal = "";

      let promise = new Promise((resolve, reject) => {
        var request = new XMLHttpRequest();

        request.open("GET", "http://173.212.198.11:3000/test/highscores", true);
        request.onload = function() {
          // Begin accessing JSON data here
          var data = JSON.parse(this.response);
          var neki = "";
          var count = 1;
          if (request.status >= 200 && request.status < 400) {
            data.message.forEach(player => {
              neki +=
                String(count++) +
                ". " +
                player.name +
                " - " +
                player.score +
                "\n&&";
            });
          } else {
            console.log("error");
          }
          this.text_kiki = neki;
          tole_bom_vracal = neki;
          return neki;
        };

        var x = request.send();

        setTimeout(() => resolve("neki"), 2000);
      });

      var y = await promise;
      console.log(tole_bom_vracal);

      var best_highscores = tole_bom_vracal.split("&&");
      this.text_kiki = best_highscores;
    }
  },
  mounted() {
    this.burek();
  }
};
</script>

<style>
#app {
  font-family: "Avenir", Helvetica, Arial, sans-serif;
  -webkit-font-smoothing: antialiased;
  -moz-osx-font-smoothing: grayscale;
  text-align: center;
  color: #2c3e50;
  margin-top: 60px;
}
</style>
